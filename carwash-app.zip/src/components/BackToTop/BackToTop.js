import React from "react";

const BackToTop = (props) => {
  return (
    <>
      <a href="/#" className="back-to-top">
        <i className="fas fa-angle-up"></i>
      </a>
    </>
  );
};

export default BackToTop;
